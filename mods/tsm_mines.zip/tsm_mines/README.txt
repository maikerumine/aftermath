Minetest mod "Mines"
====================
version: 0.3 Beta

License of source code and textures: WTFPL
-----------------------------------------
(c) Copyright BlockMen (2013)


Contributors:
-------------
cHyper (mine deep can be set by .conf)

This program is free software. It comes without any warranty, to
the extent permitted by applicable law. You can redistribute it
and/or modify it under the terms of the Do What The Fuck You Want
To Public License, Version 2, as published by Sam Hocevar. See
http://sam.zoy.org/wtfpl/COPYING for more details.


Using the mod:
--------------

This mod adds abandoned mines, similar to MC. 

You can find chest with different stuff like food, resources, ingots or even tools.


Remember that this mod is still beta!


Settings
--------

You can change the spawing of mines by adding/changing these values in minetest.conf


mines_deep_min = -64
^ at this deep mines are created
mines_deep_max = -380
^ up to this deep mines are created
mines_spawnfactor = 1.5
^ increase this value to generate more mines